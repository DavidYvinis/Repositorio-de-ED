Pen
=====


Para instalar as dependencias no ubuntu 14.04::

    sudo apt-get install g++ git libsfml-dev libsfml-audio2 libsfml-doc libsfml-graphics2 libsfml-network2 libsfml-system2 libsfml-window2
